#!/bin/bash
#环境初始化
HOST_IP=`ifconfig  eth0 | grep -w inet | awk '{print $2}'`
PWD=`pwd`
NOVA_CONFIG_FILE="${PWD}/nova-compute.tar.gz"
NEUTRON_CONFIG_FILE="${PWD}/neutron-compute.tar.gz"


yum install centos-release-openstack-stein -y
yum install python-openstackclient  openstack-selinux -y
yum install openstack-nova-compute -y 

cat ./sysctl.conf > /etc/sysctl.conf
cat ./limits.conf > /etc/security/limits.conf
cat ./profile > /etc/profile


#安装nova agent

echo "计算服务器agent安装完成，即将替换配置文件" && sleep 1
tar xvf ${NOVA_CONFIG_FILE} -C  /etc/nova/

echo "替换配置文件,即将修改vncproxy监听的IP地址" && sleep 1

sed -i "s/server_proxyclient_address = 192.168.7.103/server_proxyclient_address = ${HOST_IP}/g" /etc/nova/nova.conf

echo "启动nova服务"
systemctl enable libvirtd.service openstack-nova-compute.service
#systemctl start libvirtd.service openstack-nova-compute.service

echo "启动nova服务启动完成!" && sleep 1

#安装neutron agent
yum install openstack-neutron-linuxbridge ebtables ipset -y
echo  "网络服务安装完成，即将开始替换配置文件"
tar xvf ${NEUTRON_CONFIG_FILE} -C /etc/neutron

echo "启动neutron服务"
systemctl enable neutron-linuxbridge-agent.service

echo "计算节点安装完成,请查看相关日志或在OpenStack 管理界面确认计算服务是否自动添加" 
echo "5秒后重启服务器"
sleep 1 && echo 5
sleep 1 && echo 4
sleep 1 && echo 3
sleep 1 && echo 2
sleep 1 && echo 1
#shutdown  -r +1 "系统将在1分钟后成重启，以让内核参数和优化参数生效"
reboot
